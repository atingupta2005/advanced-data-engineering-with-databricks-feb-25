# Databricks notebook source
print("Hello from minimal Databricks notebook!")